---
name: Segnala Problemi ad un Server
about: Invio segnalazione per un server non funzionante
title: 'Inserisci il nome del server'
labels: Problema Server
assignees: ''

---

**Per poter scrivere o allegare file nella pagina devi:**
    - cliccare sui [ ... ] in alto a destra della scheda 
    - Edit. Da questo momento puoi scrivere e/o inviare file.


Inserisci il nome del server che indica problemi e se il problema è circoscritto ad un solo canale, indicalo


- Allega il file di log nella sua completezza. Non cancellarne delle parti.

